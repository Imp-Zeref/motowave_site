import { ReactNode } from 'react'
import { Inter } from 'next/font/google'

export const metadata = {
  title: 'MotoWave',
  description: 'App de manutenção preventiva para motocicletas',
}

const inter = Inter({ subsets: ['latin'] })

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.className} bg-background text-icon overflow-x-hidden`}>
        {children}
      </body>
    </html>
  )
}