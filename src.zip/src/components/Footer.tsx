import { Wrench } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-background border-t border-primary/30 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <Wrench className="h-8 w-8 text-icon" />
            <span className="text-xl font-bold text-primary">MotoWave</span>
          </div>
          <div className="text-icon/50 text-center md:text-right text-sm">
            <p>&copy; 2025 MotoWave. Todos os direitos reservados.</p>
            <p>Mantenha sua paixão sempre em movimento.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}