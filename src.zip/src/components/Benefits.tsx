import { CheckCircle } from 'lucide-react'

const benefitsList = [
  "Economize até 70% em manutenções corretivas",
  "Aumente a vida útil da sua motocicleta",
  "Mantenha a garantia sempre em dia",
  "Evite quebras inesperadas na estrada",
  "Melhore a performance e economia de combustível"
]

export default function Benefits() {
  return (
    <section id="benefits" className="py-20 relative">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl sm:text-5xl font-bold mb-8 text-primary">
              Por que escolher <span className="text-icon">o MotoWave?</span>
            </h2>
            <div className="space-y-6">
              {benefitsList.map((benefit, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
                  <span className="text-icon/70">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="bg-secondary p-8 rounded-3xl backdrop-blur-sm border border-primary/30 text-center">
              <div className="text-6xl font-bold text-primary mb-2">70%</div>
              <div className="text-xl text-icon mb-4">Economia em reparos</div>
              <div className="text-icon/70">Usuários do MotoWave economizam em média 70% em manutenções corretivas</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}