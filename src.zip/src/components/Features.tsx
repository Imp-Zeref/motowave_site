import { Clock, Shield, Wrench, Smartphone, CheckCircle, Star } from 'lucide-react'

const featuresList = [
  { icon: <Clock className="h-12 w-12 text-primary" />, title: "Lembretes Inteligentes", description: "Receba notificações baseadas na quilometragem e tempo de uso" },
  { icon: <Shield className="h-12 w-12 text-primary" />, title: "Histórico Completo", description: "Registro detalhado de todas as manutenções realizadas" },
  { icon: <Wrench className="h-12 w-12 text-primary" />, title: "Guias Passo a Passo", description: "Tutoriais detalhados para manutenções em casa" },
  { icon: <Smartphone className="h-12 w-12 text-primary" />, title: "Interface Intuitiva", description: "Design moderno e fácil de usar" },
  { icon: <CheckCircle className="h-12 w-12 text-primary" />, title: "Checklist Personalizado", description: "Listas de verificação adaptadas ao seu modelo" },
  { icon: <Star className="h-12 w-12 text-primary" />, title: "Oficinas Parceiras", description: "Encontre oficinas especializadas próximas a você" }
]

export default function Features() {
  return (
    <section id="features" className="py-20 relative">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-primary">
            Recursos Incríveis
          </h2>
          <p className="text-xl text-icon/70 max-w-2xl mx-auto">
            Tudo que você precisa para manter sua moto em perfeito estado
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuresList.map((feature, i) => (
            <div key={i} className="bg-secondary p-8 rounded-2xl border border-primary/30 hover:border-primary transition-all duration-300 hover:scale-105 backdrop-blur-sm">
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-icon">{feature.title}</h3>
              <p className="text-icon/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}