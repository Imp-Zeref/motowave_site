import { Wrench, Menu, X } from 'lucide-react'

interface HeaderProps {
  isMenuOpen: boolean
  setIsMenuOpen: (isOpen: boolean) => void
  scrollToSection: (id: string) => void
}

const navLinks = [
  { id: 'features', label: 'Recursos' },
  { id: 'benefits', label: 'Benefícios' },
  { id: 'testimonials', label: 'Depoimentos' },
  { id: 'download', label: 'Download' },
]

export default function Header({ isMenuOpen, setIsMenuOpen, scrollToSection }: HeaderProps) {
  return (
    <nav className="fixed top-0 w-full z-50 bg-background/95 backdrop-blur-sm border-b border-primary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <Wrench className="h-8 w-8 text-icon" />
            <span className="text-xl font-bold text-primary">MotoWave</span>
          </div>

          <div className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="hover:text-primary transition-colors font-semibold"
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => scrollToSection('download')}
              className="bg-primary px-6 py-2 rounded-full hover:shadow-lg hover:shadow-primary/25 transition-all text-background font-semibold"
            >
              Baixar App
            </button>
          </div>

          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-background/95 backdrop-blur-sm border-t border-primary/30">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="block px-3 py-2 hover:text-primary transition-colors w-full text-left font-semibold"
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => scrollToSection('download')}
                className="block px-3 py-2 bg-primary rounded-lg mt-2 text-background w-full font-semibold"
              >
                Baixar App
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}