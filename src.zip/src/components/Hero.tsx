import { ChevronDown } from 'lucide-react'

interface HeroProps {
  scrollToSection: (id: string) => void
}

export default function Hero({ scrollToSection }: HeroProps) {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-background">
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          <span className="text-primary">MotoWave</span>
          <br />
          <span className="text-icon">Sua Moto Sempre Saudável</span>
        </h1>
        <p className="text-xl text-icon/70 mb-8 max-w-2xl mx-auto">
          Acompanhe a manutenção da sua motocicleta, previna problemas e economize tempo e dinheiro.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={() => scrollToSection('download')}
            className="bg-primary px-8 py-4 rounded-full text-background font-semibold hover:shadow-lg hover:shadow-primary/25 transition transform hover:scale-105"
          >
            📱 Baixar Grátis
          </button>
          <button
            onClick={() => scrollToSection('features')}
            className="border-2 border-primary px-8 py-4 rounded-full text-icon font-semibold hover:bg-primary hover:text-background transition transform hover:scale-105"
          >
            Ver Recursos
          </button>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="h-8 w-8 text-primary" />
      </div>
    </section>
  )
}