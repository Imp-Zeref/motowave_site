export default function DownloadCTA() {
    return (
      <section id="download" className="py-20 relative">
        <div className="relative max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-primary">
            Baixe agora e transforme <span className="text-icon">sua experiência de pilotagem</span>
          </h2>
          <p className="text-xl text-icon/70 mb-8 max-w-2xl mx-auto">
            Junte-se a milhares de motociclistas que já descobriram como manter suas motos sempre em perfeito estado.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <button className="bg-primary px-8 py-4 rounded-full text-background font-semibold hover:shadow-lg hover:shadow-primary/25 transition transform hover:scale-105">
              📱 App Store
            </button>
            <button className="bg-primary px-8 py-4 rounded-full text-background font-semibold hover:shadow-lg hover:shadow-primary/25 transition transform hover:scale-105">
              🤖 Google Play
            </button>
          </div>
          <div className="text-sm text-icon/50">
            Disponível para iOS e Android • Grátis para baixar
          </div>
        </div>
      </section>
    )
  }